import 'dart:async';

import 'package:english_words/english_words.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'autentication_notifier.dart';



void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(App());
}

class App extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => SettingNotifier(),
      child: FutureBuilder(
        future: _initialization,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Scaffold(
                body: Center(
                    child: Text(snapshot.error.toString(),
                        textDirection: TextDirection.ltr)));
          }
          if (snapshot.connectionState == ConnectionState.done) {
            return const MyApp();
          }
          return const Center(child: CircularProgressIndicator());
        },
      ),
    );
  }
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Startup Name Generator',
      theme: ThemeData(
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.white,
        ),
      ),
      home: const RandomWords(),
    );
  }
}

class RandomWords extends StatefulWidget {
  const RandomWords({super.key});

  @override
  State<RandomWords> createState() => _RandomWordsState();
}

class _RandomWordsState extends State<RandomWords> {
  final _suggestions = <WordPair>[];
  final _biggerFont = const TextStyle(fontSize: 18);
  bool isLoginDisabled = false;
  bool isSignupDisabled = false;
  bool isLogedIn = false;
  Timer? timer;



  sync() {
    final saved = Provider.of<SettingNotifier>(context, listen: false);
    timer = Timer.periodic(
        const Duration(seconds: 10), (timer) => saved.syncSaved());
  }

  unSync() {
    timer?.cancel();
  }

  void _pushLogin() {
    var authService = Provider.of<SettingNotifier>(context, listen: false);
    Navigator.of(context).push(
        MaterialPageRoute<void>(
            builder: (context) {
              var auth = Provider.of<SettingNotifier>(context, listen: false);
              final TextEditingController emailController = TextEditingController();
              final TextEditingController passwordController = TextEditingController();
              return Scaffold(
                  appBar: AppBar(
                    title: const Text('Login'),
                  ),
                  body: Align(
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          const Text(
                            "Welcome to Startup Names Generator, please log in!",
                            style: TextStyle(fontSize: 15),
                          ),
                          TextField(
                            obscureText: false,
                            controller: emailController,
                            decoration: InputDecoration(
                              labelText: 'Email',
                            ),
                          ),
                          TextField(
                            obscureText: true,
                            controller: passwordController,
                            decoration: InputDecoration(
                              labelText: 'Password',
                            ),
                          ),
                          TextButton(
                            style: ButtonStyle(
                              foregroundColor: const MaterialStatePropertyAll<
                                  Color>(Colors.white),
                              backgroundColor: const MaterialStatePropertyAll<
                                  Color>(Colors.deepPurple),
                              shape: MaterialStateProperty.all(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.0),
                                  side: const BorderSide(width: 3,
                                      color: Colors.deepPurple),
                                ),
                              ),
                            ),
                            onPressed: isLoginDisabled ? null : () {
                              setState(() {
                                isLoginDisabled = true;
                              });
                              auth.signIn(
                                  emailController.text, passwordController.text,
                                  context).then((value) async {
                                if (value) {
                                  setState(() {
                                    isLoginDisabled = false;
                                    isLogedIn = true;
                                  });
                                  const snack = SnackBar(
                                    content: Text('Login success'),
                                    duration: Duration(seconds: 3),
                                  );
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      snack);
                                  sync();
                                  passwordController.clear();
                                  emailController.clear();
                                  Navigator.of(context).pop();
                                } else {
                                  passwordController.clear();
                                  var snak = const SnackBar(
                                    content: Text(
                                        'There was an error logging into the app'),
                                    duration: Duration(seconds: 3),
                                  );
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      snak);
                                  setState(() {
                                    isLoginDisabled = false;
                                  });
                                }
                              });
                            },
                            child: Column(
                              children: const <Widget>[
                                Text("Login"),
                              ],
                            ),
                          ),

                          TextButton(
                            style: ButtonStyle(
                              foregroundColor: const MaterialStatePropertyAll<
                                  Color>(Colors.white),
                              backgroundColor: const MaterialStatePropertyAll<
                                  Color>(Colors.deepPurple),
                              shape: MaterialStateProperty.all(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.0),
                                  side: const BorderSide(width: 3,
                                      color: Colors.deepPurple),
                                ),
                              ),
                            ),
                            onPressed: () async {
                              if (isSignupDisabled) {
                                return;
                              }
                              setState(() {
                                isSignupDisabled = true;
                              });
                              auth.singUp(
                                  emailController.text, passwordController.text,
                                  context).then((value) {
                                if (value != null) {
                                  const snack = SnackBar(
                                    content: Text('Signup success'),
                                    duration: Duration(seconds: 3),
                                  );
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      snack);
                                  passwordController.clear();
                                  emailController.clear();
                                  isSignupDisabled = false;
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            'There was an error signing up'),
                                        duration: Duration(seconds: 3),
                                      ));
                                  passwordController.clear();
                                  setState(() {
                                    isSignupDisabled = false;
                                  });
                                }
                              });
                            },
                            child: Column(
                              children: const <Widget>[
                                Text("Sign up"),
                              ],
                            ),
                          ),
                        ],
                      )
                  )
              );
            }
        )
    );
  }

  void _pushSaved() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) {
          var auth = Provider.of<SettingNotifier>(context, listen: false);
          final tiles = auth.saved.map(
                (pair) {
              return Dismissible(
                background: Container(
                    color: Colors.deepPurple,
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Row(
                            children: const [
                              Icon(
                                Icons.delete,
                              ),
                              Text(
                                "Delete suggestion",
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                              )
                            ]
                        )
                    )
                ),
                key: ValueKey<String>(pair),

                confirmDismiss: (DismissDirection direction) async {
                  return await showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: const Text("Delete Suggestions"),
                        content: Text(
                            "Are you sure you want to delete $pair from your saved Suggestions?"),
                        actions: <Widget>[
                          TextButton(
                              onPressed: () {
                                Navigator.of(context).pop(true);
                                auth.saved.remove(pair);
                              },
                              child: const Text("Yes")
                          ),
                          TextButton(
                            onPressed: () => Navigator.of(context).pop(false),
                            child: const Text("No"),
                          ),
                        ],
                      );
                    },
                  );
                },

                onDismissed: (DismissDirection direction) {
                  icon:
                  Icons.delete;
                  setState(() {});
                },
                child: ListTile(
                  title: Text(
                    pair,
                    style: _biggerFont,
                  ),
                ),
              );
            },
          );
          final divided = tiles.isNotEmpty
              ? ListTile.divideTiles(
            context: context,
            tiles: tiles,
          ).toList()
              : <Widget>[];

          return Scaffold(
            appBar: AppBar(
              title: const Text('Saved Suggestions'),
            ),
            body: ListView(children: divided),
          );
        },
      ),
    );
  }

  void _pushLogout(BuildContext context)  {
    var auth = Provider.of<SettingNotifier>(context, listen: false);
    setState(() {
      isLogedIn = false;
      auth.saved.clear();
    });

    unSync();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Logged out'),
        duration: Duration(seconds: 2),
      ),
    );
    auth.logout();
  }

  @override
  Widget build(BuildContext context) {
    var loginButton = IconButton(
      icon: const Icon(Icons.login_sharp),
      onPressed: _pushLogin,
      tooltip: "Login",
    );
    var logoutButton = IconButton(
      icon: const Icon(Icons.logout_sharp),
      onPressed: () => _pushLogout(context),
      tooltip: "Logout",
    );
    var auth = Provider.of<SettingNotifier>(context, listen: false);
    return Scaffold(
      appBar: AppBar(
        title: isLogedIn ? logoutButton : loginButton,
        actions: [
          IconButton(
            icon: const Icon(Icons.star),
            onPressed: _pushSaved,
            tooltip: 'Saved Suggestions',
          ),
        ],
      ),
      body: ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16.0),
          itemBuilder: (context, i) {
            if (i.isOdd) return const Divider();
            final index = i ~/ 2;
            if (index >= _suggestions.length) {
              _suggestions.addAll(generateWordPairs().take(100));
            }
            final alreadySaved =
            auth.saved.contains(_suggestions[index].asPascalCase);
            return ListTile(
              title: Text(
                _suggestions[index].asPascalCase,
                style: _biggerFont,
              ),
              trailing: Icon(
                alreadySaved ? Icons.favorite : Icons.favorite_border,
                color: alreadySaved ? Colors.red : null,
                semanticLabel: alreadySaved ? "Remove from saved" : "Save",
              ),
              onTap: () {
                setState(() {
                  if (alreadySaved) {
                    auth.saved.remove(_suggestions[index].asPascalCase);
                  } else {
                    auth.saved.add(_suggestions[index].asPascalCase);
                  }
                });
              },
            );
          }),
    );
  }
}






